   # Simple Instagram Photo Feed With Bootstrap

This project is just a simple Instagram clone with 9 posts, created with Bootstrap 4.
It show 2 different layout usung tabs.


## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. 
See deployment for notes on how to deploy the project on a live system.

### Installing

```
https://github.com/plucodev/simple-instagram-bootstrap.git
```


## Support & Documentation

Visit http://docs.c9.io for documentation, or http://support.c9.io for support.
To watch some training videos, visit http://www.youtube.com/user/c9ide
