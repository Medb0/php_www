<?php
// 서버정보

$host = "localhost";
$user = "root";
$password = "abcd1234";
$database = "php";


return [
  "host"=>$host,
  "user"=>$user,
  "password"=>$password,
  "database"=>$database];
